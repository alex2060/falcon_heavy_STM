import math
def speed_delta(space_t):
	return 0.002*2**( (-1*(space_t/5-30)**2)/5000)

def rot_delta(space_t):
	if space_t<=500:
		return 0
	if space_t<=1000:
		return 2.5*(1/(-(space_t-1001)+2000))
	if space_t<=1500:
		return 2.5*(1/(2000))
	return 0


def rocket1A(space_t):
	if space_t>=1000:
		return -0.004
	if space_t>=900:
		return -0.002
	if space_t>=800:
		return 0.002


	return 0.02

def rocketvilocity(space_t):
	if space_t>=750:
		return 0
	return 0.004


num_time=2000
hight=0
distance=0
speed=0
angle=0
count=0
side_1_rocket_a=0.21602638284
side_2_rocket_a=0.21602638284


side_1_rocket_w=-1.91433
side_2_rocket_w=-1.39449

side_1_rocket_h=-40.1933
side_2_rocket_h=-40.6945

side_1_vilocity=0
side_2_vilocity=0


file = open("full_rock_and_rool.txt","w")
differance=10
file.write("o,side_2_rocket_a,rocket1.stl\n")
file.write("o,side_1_rocket_a,rocket1.stl\n")
file.write("o,rocket_A,whole_rocket.stl\n")
file.write("o,rocket_,rocketM.stl\n")
file.write("s,rocket_,0.1,0\n")
file.write("s,side_2_rocket_a,0.1,0\n")
file.write("s,side_1_rocket_a,0.1,0\n")
file.write("s,rocket_,0.1,0\n")
file.write("s,rocket_A,0.1,0\n")
for x in range(num_time):
	#rocket_hight,left
	#angle
	if (x%200)==0:
		file.close()
		file = open("full_rock_and_rool"+str(count)+".txt","w")
		count=count+1
	if x<=700:
		file.write("s,rocket_A,0.1,"+str(x)+"\n")
		file.write("l,rocket_A,"+str(0.1*hight)+","+str(0.1*distance)+",0,"+str(x)+"\n")
		file.write("a,rocket_A,0,0,"+str(angle)+","+str(x)+"\n")
		hight=hight-math.cos(angle)*speed
		distance=distance-math.sin(angle)*speed
		angle=angle+rot_delta(x)
		speed=speed+speed_delta(x)
	if x==700:
		side_2_rocket_a=angle
		side_1_rocket_a=angle
		side_1_vilocity=speed*0.5
		side_2_vilocity=speed*0.5

	if x>=700:

		file.write("l,rocket_,"+str(0.1*hight)+","+str(0.1*distance)+",0,"+str(x)+"\n")
		file.write("a,rocket_,0,0,"+str(angle)+","+str(x)+"\n")



		file.write("l,side_1_rocket_a,"+str(side_1_rocket_h)+","+str(side_1_rocket_w)+",0,"+str(x)+"\n")
		file.write("a,side_1_rocket_a,0,0,"+str(side_1_rocket_a)+","+str(x)+"\n")

		
		file.write("l,side_2_rocket_a,"+str(side_2_rocket_h)+","+str(side_2_rocket_w)+",0,"+str(x)+"\n")
		file.write("a,side_2_rocket_a,0,0,"+str(side_2_rocket_a)+","+str(x)+"\n")



		hight=hight-math.cos(angle)*speed
		distance=distance-math.sin(angle)*speed
		angle=angle+rot_delta(x)
		speed=speed+speed_delta(x)
		if (x%50)==0:
			print(x)
			print(side_1_rocket_a)
			print(rocket1A(x))


		if x<=1600:
			side_1_rocket_h=side_1_rocket_h-math.cos(side_1_rocket_a)*side_1_vilocity
			side_1_rocket_w=side_1_rocket_w-math.sin(side_1_rocket_a)*side_1_vilocity
			side_1_rocket_a=side_1_rocket_a+rocket1A(x)
			side_1_vilocity=side_1_vilocity-rocketvilocity(x)


			side_2_rocket_h=side_2_rocket_h-math.cos(side_2_rocket_a)*side_1_vilocity
			side_2_rocket_w=side_2_rocket_w-math.sin(side_2_rocket_a)*side_1_vilocity
			side_2_rocket_a=side_2_rocket_a+rocket1A(x)
			side_2_vilocity=side_2_vilocity-rocketvilocity(x)


		if x>=1400:
			side_1_rocket_h=side_1_rocket_h*0.98
			side_1_rocket_a=side_1_rocket_a*0.98

			side_2_rocket_h=side_2_rocket_h*0.98
			side_2_rocket_a=side_2_rocket_a*0.98
		elif x>=1200:

			side_2_rocket_h=side_2_rocket_h-math.cos(side_2_rocket_a)*side_1_vilocity
			side_2_rocket_w=side_2_rocket_w-math.sin(side_2_rocket_a)*side_1_vilocity
			side_2_rocket_a=side_2_rocket_a+rocket1A(x)
			side_2_vilocity=side_2_vilocity-side_2_vilocity*0.1


			side_1_rocket_h=side_1_rocket_h-math.cos(side_1_rocket_a)*side_1_vilocity
			side_1_rocket_w=side_1_rocket_w-math.sin(side_1_rocket_a)*side_1_vilocity
			side_1_rocket_a=side_1_rocket_a+rocket1A(x)
			side_1_vilocity=side_1_vilocity-side_1_vilocity*0.1

